﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASM2.Manager;
using ASM2.Model;

namespace ASM2.Manager
{
    class ManagerIndustry
    {
        public static List<Industry> listindustry = new List<Industry>();
        public static Industry CheckIndustry(string IDIndustry)
        {
            foreach (Industry k in listindustry)
            {
                if (k.IDIndustry1.Equals(IDIndustry))
                {
                    return k;
                }
            }
            return null;
        }
        public static void add()
        {
            string IDIndustry;
            string NameIndustry;
            Industry k;
            do
            {
                Console.WriteLine("Put the ID Industry");
                IDIndustry = Console.ReadLine();
                k = CheckIndustry(IDIndustry);
                if (k != null)
                {
                    Console.WriteLine("ID Industry exist");
                    Console.WriteLine("Plese put the correct ID Industry again");
                }
            } while (k != null);
            Console.WriteLine("Name of Industry: ");
            NameIndustry = Console.ReadLine();
            listindustry.Add(new Industry(IDIndustry, NameIndustry, new List<Class>()));
            WriteFile();
        }
        public static int Menu()
        {
            int j;
            Console.WriteLine("------Management Industry-------");
            Console.WriteLine("1. List of Industry");
            Console.WriteLine("2. Find Industry");
            Console.WriteLine("3. Add Industry");
            Console.WriteLine("4. Exit");
            Console.WriteLine("Please choose from 1-4: ");
            j = CheckError.CheckChoose(Console.ReadLine());
            return j;
        }
        public static void display()
        {
            int check = 0;
            Console.WriteLine("ID Industry\t|\tName Industry\t");
            foreach (Industry k in listindustry)
            {
                check++;
                Console.WriteLine("{0}\t|\t{1}\t", k.IDIndustry1, k.NameIndustry1);
            }
            if (check == 0)
            {
                Console.WriteLine("No Industry to Show");
            }
        }
        public static void displayclass(Industry k)
        {
            if (k != null)
            {
                Console.WriteLine("ID Industry: {0}", k.IDIndustry1);
                Console.WriteLine("Name Industry: {0}", k.NameIndustry1);
                Console.WriteLine("ID Industry\t|\tName Industry\t");
                foreach (Class lop in k.Listclass)
                {
                    Console.WriteLine("{0}\t|\t{1}\t", lop.IOC1, lop.NameClass1);
                }
            }
            else
            {
                Console.WriteLine("Didnt found Industry");
            }
        }
        public static void WriteFile()
        {
            string fileName = "../../../Industry.txt";
            using (BinaryWriter writter = new BinaryWriter(File.Open(fileName, FileMode.Create)))
            {
                foreach (Industry k in listindustry)
                {
                    writter.Write(k.IDIndustry1);
                    writter.Write(k.NameIndustry1);
                }
            }
        }
        public static void readFile()
        {
            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open("../../../Industry.txt", FileMode.Open)))
                {
                    try
                    {
                        while (true)
                        {
                            Industry k = new Industry(reader.ReadString(), reader.ReadString(), new List<Class>());
                            listindustry.Add(k);
                        }
                    }
                    catch (Exception e)
                    {
                    }
                }
            }
            catch (Exception e)
            {

            }
        }
    }
}
