﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM2.Manager
{
    class CheckError
    {
        public static int CheckChoose(string check)
        {
            int menu = 0;
            try
            {
                menu = Convert.ToInt32(check);
            }
            catch (Exception ex)
            {

            }
            return menu;
        }
    }
}
