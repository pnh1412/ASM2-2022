﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASM2.Manager;
using ASM2.Model;

namespace ASM2.Manager
{
    class ManagerSchoolYear
    {
        public static List<SchoolYear> listschoolyear = new List<SchoolYear>();
        public static SchoolYear CheckSchoolYear(string IDSY)
        {
            foreach (SchoolYear s in listschoolyear)
            {
                if (s.IDSY1.Equals(IDSY))
                {
                    return s;
                }
            }
            return null;
        }
        public static void add()
        {
            string IDSY;
            string Ex;
            SchoolYear s;
            do
            {
                Console.WriteLine("Put the ID School Year");
                IDSY = Console.ReadLine();
                s = CheckSchoolYear(IDSY);
                if (s != null)
                {
                    Console.WriteLine("ID School Year exist");
                    Console.WriteLine("Plese put the correct ID School Year again");
                }
            } while (s != null);
            Console.WriteLine("Explain: ");
            Ex = Console.ReadLine();
            listschoolyear.Add(new SchoolYear(IDSY, Ex, new List<Class>()));
            WriteFile();
        }
        public static int Menu()
        {
            int j;
            Console.WriteLine("------Management School Year-------");
            Console.WriteLine("1. List of School Year");
            Console.WriteLine("2. Find School Year");
            Console.WriteLine("3. Add School Year");
            Console.WriteLine("4. Exit");
            Console.WriteLine("Please choose from 1-4: ");
            j = CheckError.CheckChoose(Console.ReadLine());
            return j;
        }
        public static void display()
        {
            int check = 0;
            Console.WriteLine("ID School Year\t|\tExplain\t");
            foreach (SchoolYear s in listschoolyear)
            {
                check++;
                Console.WriteLine("{0}\t|\t{1}\t", s.IDSY1, s.Ex1);
            }
            if (check == 0)
            {
                Console.WriteLine("No School Year to Show");
            }
        }
        public static void displayclass(SchoolYear s)
        {
            if (s != null)
            {
                Console.WriteLine("ID School Year: {0}", s.IDSY1);
                Console.WriteLine("Explain: {0}", s.Ex1);
                Console.WriteLine("ID School Year\t|\tExplain\t");
                foreach (Class lop in s.Listclass)
                {
                    Console.WriteLine("{0}\t|\t{1}\t", lop.IOC1, lop.NameClass1);
                }
            }
            else
            {
                Console.WriteLine("Didnt found School Year");
            }
        }
        public static void WriteFile()
        {
            string fileName = "../../../SchoolYear.txt";
            using (BinaryWriter writter = new BinaryWriter(File.Open(fileName, FileMode.Create)))
            {
                foreach (SchoolYear s in listschoolyear)
                {
                    writter.Write(s.IDSY1);
                    writter.Write(s.Ex1);
                }
            }
        }
        public static void readFile()
        {
            try
            {
                using (BinaryReader reader = new BinaryReader(File.Open("../../../SchoolYear.txt", FileMode.Open)))
                {
                    try
                    {
                        while (true)
                        {
                            SchoolYear s = new SchoolYear(reader.ReadString(), reader.ReadString(), new List<Class>());
                            listschoolyear.Add(s);
                        }
                    }
                    catch (Exception e)
                    {
                    }
                }
            }
            catch (Exception e)
            {

            }
        }
    }
}
