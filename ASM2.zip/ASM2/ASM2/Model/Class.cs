﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM2.Model
{
    class Class
    {
        string IOC;
        string IDIndustry;
        string IDSY; // id of school year
        string NameClass;
        List<Student> liststudent;

        public string IOC1 { get => IOC; set => IOC = value; }
        public string IDIndustry1 { get => IDIndustry; set => IDIndustry = value; }
        public string IDSY1 { get => IDSY; set => IDSY = value; }
        public string NameClass1 { get => NameClass; set => NameClass = value; }
        internal List<Student> Liststudent { get => liststudent; set => liststudent = value; }

        public Class(string iOC, string iDIndustry, string iDSY, string nameClass, List<Student> liststudent)
        {
            IOC = iOC;
            IDIndustry = iDIndustry;
            IDSY = iDSY;
            NameClass = nameClass;
            this.liststudent = liststudent;
        }

        public Class()
        {
        }
    }
}
