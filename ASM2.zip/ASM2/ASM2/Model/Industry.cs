﻿using ASM2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM2.Model
{
    class Industry
    {
        string IDIndustry;
        string NameIndustry;
        List<Class> listclass;

        public string IDIndustry1 { get => IDIndustry; set => IDIndustry = value; }
        public string NameIndustry1 { get => NameIndustry; set => NameIndustry = value; }
        internal List<Class> Listclass { get => listclass; set => listclass = value; }

        public Industry(string iDIndustry, string nameIndustry, List<Class> listclass)
        {
            IDIndustry = iDIndustry;
            NameIndustry = nameIndustry;
            this.listclass = listclass;
        }

        public Industry()
        {
        }
    }
}
