﻿using ASM2.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASM2.Model
{
    class SchoolYear
    {
        string IDSY; // 1 student's year
        string Ex;
        List<Class> listclass;

        public string IDSY1 { get => IDSY; set => IDSY = value; }
        public string Ex1 { get => Ex; set => Ex = value; }
        internal List<Class> Listclass { get => listclass; set => listclass = value; }

        public SchoolYear(string iDSY, string ex, List<Class> listclass)
        {
            IDSY = iDSY;
            Ex = ex;
            this.listclass = listclass;
        }

        public SchoolYear()
        {
        }
    }
}
